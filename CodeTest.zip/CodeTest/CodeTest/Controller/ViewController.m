//
//  ViewController.m
//  CodeTest
//
//  Created by RAJASEKHAR GOGULA on 16/04/18.
//  Copyright © 2018 CodeTest. All rights reserved.
//

#import "ViewController.h"
#import "DetailsViewController.h"
#import "Reachability.h"

@interface ViewController (){
    NSMutableArray *dataArray;

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIBarButtonItem *menu=[[UIBarButtonItem alloc]initWithImage:
                              [[UIImage imageNamed:@"menu"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                             style:UIBarButtonItemStylePlain target:self action:@selector(SaveButtonClicked)];
    self.navigationItem.leftBarButtonItem=menu;
    
    UIBarButtonItem *share=[[UIBarButtonItem alloc]initWithImage:
                              [[UIImage imageNamed:@"more"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                             style:UIBarButtonItemStylePlain target:self action:@selector(SaveButtonClicked)];
    self.navigationItem.rightBarButtonItem=share;
    
   
    
    dataArray = [[NSMutableArray alloc]init];
    
    if ([[Reachability reachabilityForInternetConnection]currentReachabilityStatus]==NotReachable)
    {
        //connection unavailable
    }
    else
    {
        //connection available
        
        NSString *urlAsString = [NSString stringWithFormat:@"http://api.nytimes.com/svc/mostpopular/v2/mostviewed/all-sections/1.json?api-key=ca31477c0aa34b9bbcae525c399f9c8c"];
        
        NSCharacterSet *set = [NSCharacterSet URLQueryAllowedCharacterSet];
        NSString *encodedUrlAsString = [urlAsString stringByAddingPercentEncodingWithAllowedCharacters:set];
        
        NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        
        [[session dataTaskWithURL:[NSURL URLWithString:encodedUrlAsString]
                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                    
                    NSLog(@"RESPONSE: %@",response);
                    NSLog(@"DATA: %@",data);
                    
                    if (!error) {
                        // Success
                        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                            NSError *jsonError;
                            NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
                            
                            if (jsonError) {
                                // Error Parsing JSON
                                
                            } else {
                                // Success Parsing JSON
                                // Log NSDictionary response:
                                NSLog(@"%@",jsonResponse);
                                NSLog(@"%@",[jsonResponse objectForKey:@"results"]);
                                dataArray = [jsonResponse objectForKey:@"results"];
                                NSLog(@"dataArray count:%@",dataArray);
                                //[[dataArray valueForKey:@"title"] objectAtIndex:indexPath.row]
                                NSLog(@"dataArray count:%@",[[dataArray valueForKey:@"title"] objectAtIndex:0]);
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    // code here
                                    [self.tableView reloadData];
                                    
                                });
                                
                            }
                        }  else {
                            //Web server is returning an error
                        }
                    } else {
                        // Fail
                        NSLog(@"error : %@", error.description);
                    }
                }] resume];
    }
    
}
-(void)SaveButtonClicked
{
    // Add save button code.
}
#pragma mark UI TableviewDelegate Methods


//Data Souce Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return dataArray.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
        
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
     cell.textLabel.text =[NSString stringWithFormat:@"%@",[[dataArray valueForKey:@"title"] objectAtIndex:indexPath.row]];
    cell.imageView.image = [UIImage imageNamed:@"user_login.png"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[[dataArray valueForKey:@"published_date"] objectAtIndex:indexPath.row]];
    cell.detailTextLabel.textAlignment = NSTextAlignmentLeft;
    return cell;
   
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [self performSegueWithIdentifier:@"detailView" sender:self];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
