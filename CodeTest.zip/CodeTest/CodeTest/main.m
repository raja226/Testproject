//
//  main.m
//  CodeTest
//
//  Created by RAJASEKHAR GOGULA on 16/04/18.
//  Copyright © 2018 CodeTest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
